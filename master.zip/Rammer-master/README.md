# Rammer
Rammer - это операцонная система написаная на DroidScript. С версии 1.0 до 1.9.9 был закрытый бета тест.

# English
Rammer is an "operating system" written in DroidScript
